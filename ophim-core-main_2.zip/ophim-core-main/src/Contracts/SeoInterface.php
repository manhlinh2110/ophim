<?php

namespace Ophim\Core\Contracts;

interface SeoInterface
{
    public function generateSeoTags();
}
