<?php

namespace Ophim\Core\Contracts;

interface HasUrlInterface
{
    public function getUrl();
}
