<?php

namespace Ophim\Core\Contracts;

interface TaxonomyInterface extends HasUrlInterface
{
}
